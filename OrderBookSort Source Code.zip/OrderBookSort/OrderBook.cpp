
#include "OrderBook.h"

template <class T>
void OrderBook<T>::OutputBook()
{
};